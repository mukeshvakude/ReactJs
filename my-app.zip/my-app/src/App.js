

import Counter from './Component/Counter';
import HelloWorld from './Component/HelloWorld';
function App() {
  return (
    <>
    <HelloWorld/>
    <Counter/>
    </>
  );
}

export default App;
