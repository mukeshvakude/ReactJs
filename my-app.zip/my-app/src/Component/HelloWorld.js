

function HelloWorld(){
    return "Hello World";
}

export default HelloWorld;